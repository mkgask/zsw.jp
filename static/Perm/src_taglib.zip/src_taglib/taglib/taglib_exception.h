#ifndef TAGLIB_EXCEPTION_H
#define TAGLIB_EXCEPTION_H

class taglib_exception
{
public:
    int code;
    std::string msg;
};

#endif // TAGLIB_EXCEPTION_H
